<?php
    //dados para conexão com base de dados MySql
    //ajuste os dados de conexão de acordo com seu ambiente de trabalho
    $host = "localhost";
    $user = "root";
    $pass = "";
    $banco = "loja";

    //criando a linha de conexão
    $conexao = mysqli_connect($host, $user, $pass, $banco) or die ("problemas com a conexão do banco de Dados");

    








?>